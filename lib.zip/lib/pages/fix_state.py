import os
import re

home_path = r'c:\Users\ian\Desktop\final_sem_proj\swipify\lib\pages\home_page.dart'
with open(home_path, 'r', encoding='utf-8') as f:
    text = f.read()

# Replace AnimatedSwitcher with IndexedStack
tabs_regex = r'Expanded\(\n\s*child: AnimatedSwitcher\([\s\S]*?child: _buildTabContent\(\),\n\s*\),\n\s*\),'

indexed_stack_code = '''Expanded(
                    child: IndexedStack(
                      index: selectedTab,
                      children: [
                        HomeTab(
                          key: const ValueKey(0),
                          onGoToWav:     () => setState(() => selectedTab = 1),
                          onGoToMatches: () => setState(() => selectedTab = 2),
                          moodTint: _moodTintNotifier.value,
                        ),
                        WavPage(
                          key: const ValueKey(1),
                          onMoodChanged: (c) => _moodTintNotifier.value = c,
                        ),
                        MatchPage(
                          key: const ValueKey(2), 
                          uid: FirebaseAuth.instance.currentUser?.uid ?? ""
                        ),
                        const ProfilePage(key: ValueKey(3)),
                      ],
                    ),
                  ),'''

text = re.sub(tabs_regex, indexed_stack_code, text)

# Remove the _buildTabContent method entirely
build_tab_regex = r'  Widget _buildTabContent\(\) \{[\s\S]*?\}\n  \}\n'
text = re.sub(build_tab_regex, '', text)

with open(home_path, 'w', encoding='utf-8') as f:
    f.write(text)


wav_path = r'c:\Users\ian\Desktop\final_sem_proj\swipify\lib\pages\wav_page.dart'
with open(wav_path, 'r', encoding='utf-8') as f:
    wav_text = f.read()

# Make sure shared_preferences is imported
if 'shared_preferences.dart' not in wav_text:
    wav_text = wav_text.replace("import 'package:provider/provider.dart';", "import 'package:provider/provider.dart';\nimport 'package:shared_preferences/shared_preferences.dart';")

wav_text = re.sub(
    r'  bool _hintsVisible   = true;\n  bool _hintsDismissed = false;',
    r'  bool _hintsVisible   = false;\n  bool _hintsDismissed = true;',
    wav_text
)

# In initState, remove the immediate auto-dismiss and replace it with _checkTutorialStatus()
init_state_find = r'    // Auto-dismiss gesture hints after 6s\n    Future\.delayed\(const Duration\(seconds: 6\), \(\) \{\n      if \(mounted && !_hintsDismissed\) _dismissHints\(\);\n    \}\);'
init_state_repl = r'    _checkTutorialStatus();'

wav_text = re.sub(init_state_find, init_state_repl, wav_text)

# Add _checkTutorialStatus method
if '_checkTutorialStatus' not in wav_text:
    disp_idx = wav_text.find('  void _dismissHints() {')
    if disp_idx != -1:
        tutorial_method = '''  Future<void> _checkTutorialStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final hasSeen = prefs.getBool('has_seen_wav_hints') ?? false;
    if (!hasSeen) {
      if (mounted) {
        setState(() {
          _hintsVisible = true;
          _hintsDismissed = false;
        });
      }
      await prefs.setBool('has_seen_wav_hints', true);
      Future.delayed(const Duration(seconds: 6), () {
        if (mounted && !_hintsDismissed) _dismissHints();
      });
    }
  }

'''
        wav_text = wav_text[:disp_idx] + tutorial_method + wav_text[disp_idx:]

with open(wav_path, 'w', encoding='utf-8') as f:
    f.write(wav_text)

print('Done')
