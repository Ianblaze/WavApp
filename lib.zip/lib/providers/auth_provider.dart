import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../auth/auth_service.dart';

enum AuthStatus { loading, unauthenticated, authenticated, emailUnverified }

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final PhoneAuthService _phoneAuthService = PhoneAuthService();

  AuthStatus _status = AuthStatus.loading;
  User? _currentUser;

  AuthStatus get status => _status;
  User? get currentUser => _currentUser;
  String? get currentUid => _currentUser?.uid;

  AuthProvider() {
    FirebaseAuth.instance.authStateChanges().listen(_onAuthStateChanged);
  }

  void _onAuthStateChanged(User? user) {
    _currentUser = user;
    if (user == null) {
      _status = AuthStatus.unauthenticated;
    } else {
      final provider = user.providerData.isNotEmpty
          ? user.providerData.first.providerId
          : '';
      final isEmailProvider = provider == 'password';
      if (isEmailProvider && !user.emailVerified) {
        _status = AuthStatus.emailUnverified;
      } else {
        _status = AuthStatus.authenticated;
      }
    }
    notifyListeners();
  }

  Future<void> signInWithGoogle() async {
    await _authService.signInWithGoogle();
  }

  Future<void> signInWithEmail({
    required String email,
    required String password,
  }) async {
    await _authService.signInWithEmail(email: email, password: password);
  }

  Future<void> signUpWithEmail({
    required String email,
    required String password,
    required String name,
  }) async {
    await _authService.signUpWithEmail(
        email: email, password: password, name: name);
  }

  Future<void> signInWithPhone({
    required String phoneNumber,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    await _phoneAuthService.sendOtp(
      phoneNumber: phoneNumber,
      onCodeSent: onCodeSent,
      onError: onError,
    );
  }

  Future<void> verifyOtp({
    required String otp,
    required String verificationId,
    required Function(String error) onError,
  }) async {
    await _phoneAuthService.verifyOtp(
      otp: otp,
      verificationId: verificationId,
      onError: onError,
    );
  }

  Future<void> signOut() async {
    await _authService.signOut();
  }

  Future<void> sendVerificationEmail() async {
    await _currentUser?.sendEmailVerification();
  }

  Future<void> checkEmailVerification() async {
    await _currentUser?.reload();
    final refreshed = FirebaseAuth.instance.currentUser;
    if (refreshed != null) {
      _onAuthStateChanged(refreshed);
    }
  }
}
