import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/user_profile.dart';

class UserProfileProvider extends ChangeNotifier {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  UserProfile? _profile;
  StreamSubscription<DocumentSnapshot>? _profileStream;

  UserProfile? get profile => _profile;

  void startListening(String uid) {
    _profileStream?.cancel();
    _profileStream = _db.collection('users').doc(uid)
        .snapshots()
        .listen((doc) {
      if (doc.exists) {
        _profile = UserProfile.fromDoc(doc);
        notifyListeners();
      }
    });
  }

  void stopListening() {
    _profileStream?.cancel();
    _profileStream = null;
    _profile = null;
    notifyListeners();
  }

  Future<void> updateProfile({String? username, String? photoUrl}) async {
    if (_profile == null) return;
    final updates = <String, dynamic>{};
    if (username != null) updates['username'] = username;
    if (photoUrl != null) updates['photoUrl'] = photoUrl;
    if (updates.isEmpty) return;
    await _db.collection('users').doc(_profile!.uid).update(updates);
  }

  @override
  void dispose() {
    _profileStream?.cancel();
    super.dispose();
  }
}
